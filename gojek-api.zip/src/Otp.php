<?php

namespace Imdvlpr;
use PDO;
use PDOException;

class Otp {
    
    private $connection;

    public function __construct() {
        try {
            $this->connection = new PDO("mysql:host=". SERVER_NAME . "dbname=" . DATABASE, USERNAME, PASSWORD);
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }

    public function sendOtp($phone, $isResend) {
        $timestamp = time();
        $userkey = '64707c333434';
        $passkey = 'be5c4a928db531eac41dea01';
        $otp_code = mt_rand(1000, 9999);;
        $url = 'https://console.zenziva.net/waofficial/api/sendWAOfficial/';

        if ($_POST['is_resend'] == "true") {
            $isResend = true;
        } else {
            $isResend = false;
        }

        $curlHandle = curl_init();
        curl_setopt($curlHandle, CURLOPT_URL, $url);
        curl_setopt($curlHandle, CURLOPT_HEADER, 0);
        curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curlHandle, CURLOPT_TIMEOUT, 30);
        curl_setopt($curlHandle, CURLOPT_POST, 1);
        curl_setopt($curlHandle, CURLOPT_POSTFIELDS, array(
            'userkey' => $userkey,
            'passkey' => $passkey,
            'to' => $phone,
            'brand' => 'Sobat Dompet',
            'otp' => $otp_code));

        $results = json_decode(curl_exec($curlHandle), true);
        curl_close($curlHandle);
        $messageId = $results['messageId'];

        $sql = "INSERT INTO auth (message_id, otp_number, timestamp, status) VALUES ('$messageId', '$otp_code', '$timestamp', 'waiting')";

        if ($this->connection->query($sql)) {
            $response = array(
                "success" => true,
                "message" => "Kirim OTP berhasil",
                "message_id" => $messageId,
                "is_resend" => $isResend,
                "time_in_second" => 60
            );

            $jsonResponse = json_encode($response);
            header("Content-Type: application/json");
            return $jsonResponse;
        }
    }
}